function ADVR.onLoad()
    achievement.name = "Mind If We Pop In?"
	achievement.desc = "Overcome a Challenge Chest's trial."
	achievement.hideDescription = false
	achievement.unlocksItem = relics.ERTHU_CHRWA_DEAFENING_BELL
	achievement.insightReward = 3
end