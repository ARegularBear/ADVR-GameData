function ADVR.onLoad()
	progress.name = "Mana Mastery"
	progress.desc = "Mana replenishes more quickly"
	progress.price = 1
	progress.predecessor = nil
end

function ADVR.ProgressEvents.onBuy()
end